//CS2211a 2020
//Assignment number: 1
//Alexander Hemming
//251033611
//ahemmin
//9/21/20
//
#include <stdio.h>
int main(void)
{
	printf("Hello World!");
}

